#!/bin/bash

tests1=(""
    "0"
    "8"
    "toto"
    "blah blah"
    "-i"
    "-bidule"
    "4" #not enough
    "4 5 6" #too many
    "4 0" #invalid
    "4 -5") #invalid

test_files=("pmouli/fasta/easy.fa"
    "pmouli/fasta/ex.fasta"
    "pmouli/fasta/so.fa"
    "pmouli/fasta/test.fa"
    "pmouli/fasta/truc.fa"
    "pmouli/fasta/vide.fa"
    "pmouli/fasta/nnn.fasta"
    "pmouli/fasta/wiki.fa"
    "pmouli/fasta/f.fa"
    "pmouli/fasta/t.fa"
    "pmouli/fasta/fichier_de_merde.fasta")

test_files7=("pmouli/fasta/easy.fa"
    "pmouli/fasta/ex.fasta"
    "pmouli/fasta/test.fa"
    "pmouli/fasta/sample.fa")

k_list=(1 2 3 5 8 10 20)

BIN=FASTAtools
R_REF='pmouli/bin/r_ref'
P_REF='pmouli/bin/p_ref'
HEADER='--- Moulinette '$BIN' ---'
FOOTER='Version 0.2 - June 21 2016'

p=0
t=$((${#tests1[@]}+${#test_files[@]}*5+${#test_files7[@]}+${#k_list[@]}*${#test_files[@]}))
verbose=false
tips=false
requirement=false
diff=false
slow=false

### Formatting vars
COLS=$(tput cols)
WIDTH=$((${#HEADER}/2))
CENTERCOL=$(($COLS/2))
CENTERCOL=$(($CENTERCOL-$WIDTH))

BLK=$(tput setaf 0)
RED=$(tput setaf 1)
GRN=$(tput setaf 2)
YEL=$(tput setaf 3)
BLU=$(tput setaf 4)
MAG=$(tput setaf 5)
CYN=$(tput setaf 6)
WHI=$(tput setaf 7)
NRM=$(tput sgr0)
BLD=$(tput bold)
######

function help {
    echo $(tput cuf $CENTERCOL)$BLD$CYN$HEADER$NRM
#    echo $RED'Important warning! This is a preview. The Fistinette has not been delivered yet and the tests that you pass may not correspond to the expected results'$NRM
    echo $BLD'SYNOPSIS'$NRM
    echo -e '\t./mouli.sh [-v] [-t] [-r] [-d] [-s] [-m]'
    echo $BLD'DESCRIPTION'$NRM
    echo -e '\tTest your '$BIN' project! This script runs bash.'
    echo -e '\t'$BLD'-v'$NRM'\n\t\tverbose output. Display tests that are being run.'
    echo -e '\t'$BLD'-t'$NRM'\n\t\ttips. Display a few tips and things you may have overlooked.'
    echo -e '\t'$BLD'-r'$NRM'\n\t\trequirement. Test your requirement function(s) instead.'
    echo -e '\t'$BLD'-d'$NRM'\n\t\tdifference. Display differences between the reference binary and yours.'
    echo -e '\t'$BLD'-s'$NRM'\n\t\tslow. Stop the execution after each option has been tested.'
    echo -e '\t'$BLD'-m'$NRM'\n\t\tmono. Disable colored output and print everything in black and white instead. Useful for redirecting output to a legible file.'
    echo -e '\t'$BLD'-h'$NRM'\n\t\thelp. Display this help.'
    echo $BLD'AUTHOR'$NRM
    echo -e '\tMade by Lucien Le Roux'
    echo $BLD'NOTES'$NRM
    echo -e '\tThe purpose of this program is only informative. It does not guarantee that the Fistinette will not Fist you, but it can give you a hint as to where to look for errors on your side.\n'
    echo -e $(tput cuf $CENTERCOL)$FOOTER
}

function disable_colors {
    BLK=
    RED=
    GRN=
    YEL=
    BLU=
    MAG=
    CYN=
    WHI=
    NRM=
    BLD=
}

for k in $*; do
    case $k in
	'-v')	verbose=true;;
	'-t')	tips=true;;
	'-r')	requirement=true;;
	'-d')	diff=true;;
	'-s')	slow=true;;
	'-m')	disable_colors;;
	'-h')	help; exit 0;;
	*)	;;
    esac
done

###   Functions            ###
function term {
    echo 'Fistinette terminated with status '$1
    echo 'Passed tests: '$((100*$p/$t))'% ('$p'/'$t')'
    exit $1
}

function stop {
    if [ $slow == true ]; then
	tput cuf $CENTERCOL
	echo -n $MAG'Press any key to continue'$NRM
	read -s -n 1
	echo
    fi
}

function check {

    function status_detail {
	case $1 in
	    134) echo $YEL' Aborted'$NRM;;
	    139) echo $YEL' Seg fault'$NRM;;
	    *) echo;;
	esac
    }

    function check_timeout {
	case $1 in
	    124) echo -n $YEL' Timed out'$NRM;;
	    *) ;;
	esac
    }

    printf ">"
    if [ $1 == $2 ]; then
	p=$(($p+1));
	printf "${GRN}%6s${NRM}" 'OK'
    else
	printf "${RED}%6s${NRM}" 'KO'
    fi
    printf "   (%3d/%3d)" $3 $4
    check_timeout $1
    status_detail $3
    if [ $diff == true ]; then
	if [ ! -z ${5+x} ] && [ ! -z ${6+x} ]; then
	    if [ "$5" != "$6" ]; then
		echo -e $RED' < '$5$NRM
		echo -e $GRN' > '$6$NRM
		echo
	    else
		echo $GRN'      Same output'$NRM
	    fi
	else
	    echo $YEL'      Output does not matter'$NRM
	fi
    fi
    sleep 0.01
}

###   Tips                 ###
if [ $tips == true ]; then
    echo $BLD'Here are a few tips or points you may have overlooked'$NRM
    cat pmouli/tips
    exit 0
fi

###   Requirement          ###
if [ $requirement == true ]; then
    echo '1. Testing requirement'
    t=1
    gcc -o r_test pmouli/r_main.c requirement.c &> /dev/null
    if [ $? != 0 ]; then
	echo $RED'Cannot continue: compilation failed. Are the files '$BLD'r_main.c'$NRM$RED' and '$BLD'requirement.c'$NRM$RED' in the current directory ?'$NRM
	term 3
    fi
    a=$(./r_test)
    status=$?
    b=$(./$R_REF)
    (diff <(echo "${a}") <(echo "${b}") &> /dev/null) ; check $? 0 $status 0 "${a}" "${b}"
    rm -f r_test
    term 0
fi





###   Compilation          ###
echo '1.  Compiling project...'
make re &> /dev/null
make clean &> /dev/null
if [ $? != 0 ]; then
    if [ ! -f ./$BIN ]; then echo -e $RED'Cannot continue: binary '$BLD$BIN$NRM$RED' not found. Invalid name ?'$NRM;
    else echo -e $RED'Cannot continue: compilation failed.'$NRM; fi
    term 1
fi



###   Retrieving binary    ###
echo '2.  Looking for reference binary...'
if [ ! -f $P_REF ]; then
    echo -e $RED'Cannot continue: reference binary '$BLD$P_REF$NRM$RED'is nowhere to be found.'$NRM
    term 2
fi



###   Actual testing       ###
echo '3.  Starting tests...'

echo $CYN'  1. Error handling'$NRM
c=1
for test in "${tests1[@]}"; do
    if [ $verbose == true ]; then printf "[%02d] ./%s %-50s" $c $BIN "${test}"; fi
    (timeout 2 ./$BIN $test &> /dev/null); check $? 84 $? 84
    c=$(($c+1))
done
stop

n=1
while [ $n -lt 4 ]; do
    echo $CYN'  2. '$n' option'$NRM
    c=1
    for test in "${test_files[@]}"; do
	if [ $verbose == true ]; then printf "[%02d] ./%s %d < %-46s" $c $BIN $n "${test}"; fi
	a=$(./$BIN $n < $test 2> /dev/null)
	status=$?
	b=$(./$P_REF $n < $test 2> /dev/null)
	(diff <(echo "${a}") <(echo "${b}") &> /dev/null) ; check $? 0 $status 0 "${a}" "${b}"
	c=$(($c+1))
    done
    stop
    n=$(($n+1))
done

while [ $n -lt 5 ]; do
    echo $CYN'  2. '$n' option'$NRM
    c=1
    for test in "${test_files[@]}"; do
	for k in ${k_list[@]}; do
	    if [ $verbose == true ]; then printf "[%02d] ./%s %d %-2d < %-43s" $c $BIN $n $k "${test}"; fi
	    a=$(./$BIN $n $k < $test 2> /dev/null)
	    status=$?
	    b=$(./$P_REF $n $k < $test 2> /dev/null)
	    (diff <(echo "${a}") <(echo "${b}") &> /dev/null) ; check $? 0 $status 0 "${a}" "${b}"
	    c=$(($c+1))
	done
    done
    stop
    n=$(($n+1))
done

while [ $n -lt 7 ]; do
    echo $CYN'  2. '$n' option'$NRM
    c=1
    for test in "${test_files[@]}"; do
	if [ $verbose == true ]; then printf "[%02d] ./%s %d < %-46s" $c $BIN $n "${test}"; fi
	a=$(./$BIN $n < $test 2> /dev/null)
	status=$?
	b=$(./$P_REF $n < $test 2> /dev/null)
	(diff <(echo "${a}") <(echo "${b}") &> /dev/null) ; check $? 0 $status 0 "${a}" "${b}"
	c=$(($c+1))
    done
    stop
    n=$(($n+1))
done

while [ $n -lt 8 ]; do
    echo $CYN'  2. '$n' option'$NRM
    c=1
    for test in "${test_files7[@]}"; do
	if [ $verbose == true ]; then printf "[%02d] ./%s %d < %-46s" $c $BIN $n "${test}"; fi
	a=$(./$BIN $n < $test 2> /dev/null)
	status=$?
	b=$(./$P_REF $n < $test 2> /dev/null)
	(diff <(echo "${a}") <(echo "${b}") &> /dev/null) ; check $? 0 $status 0 "${a}" "${b}"
	c=$(($c+1))
    done
    n=$(($n+1))
done

echo '---------------------------------------------------------------------'

term 0
