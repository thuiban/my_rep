#include <string.h>
#include <stdio.h>

char	*my_strcapitalize_synthesis(char *str);

int	main(int ac, char **av)
{
  char	str[64];
  char	*test[] = {
    "",
    "rien",
    "rien du tout",
    "   toujours rien",
    "   toujours    rien    ",
    "     ",
    "    wz454545az 6f",
    "  N+P 42words",
    ".EXCELLENT CA        9",
    "hey, how are you? 42words forty-two; fifty+one",
    ";a",
    NULL
  };
  int	i;

  for (i = 0; test[i]; i++)
    {
      strcpy(str, test[i]);
      printf("[%s]\n", my_strcapitalize_synthesis(str));
    }
  return 0;
}
