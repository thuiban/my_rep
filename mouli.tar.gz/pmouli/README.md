# Mouli
## Synthesis pool project tester

## How to use
Your project root must be where the file is.

To launch mouli.sh
`./mouli.sh`

For any help, try the -h option.

## Feedback
Please reports any bug or improvement idea to lucien.le-roux@epitech.eu.

## Version
Mouli v0.1.3 - 2016