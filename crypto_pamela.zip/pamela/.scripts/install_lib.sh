#!/bin/bash

#Init
DIR="/lib/security"
LIB="pamela_mod.so"
#
if [[ $EUID -ne 0 ]]; then
    echo "This rule must be run as root" 1>&2
    exit 1
fi
if [[ ! -d $DIR  ]]; then
    mkdir $DIR
fi

cp $LIB $DIR
chown root:root "$DIR/$LIB"
chmod 755 "$DIR/$LIB"

cryptsetup 2> /dev/null

if [[ $? -eq 127 ]]; then
 apt-get update
 apt-get install -y cryptsetup
fi

grep $LIB /etc/pam.d/common-session >> /dev/null
if [[ $? -ne 0 ]]; then
    cp /etc/pam.d/common-session /etc/pam.d/common-session.back
    TMP=$(cat -n /etc/pam.d/common-session | grep pam_unix.so | awk '{print $1;}')
    let TMP--
    sed -e "$TMP a session optional        $LIB"   /etc/pam.d/common-session > /etc/pam.d/tmp.txt
    mv /etc/pam.d/tmp.txt /etc/pam.d/common-session
fi

make clean
echo "Installation done."