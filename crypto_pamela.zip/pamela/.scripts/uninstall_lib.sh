#!/bin/bash

#Init
DIR="/lib/security"
LIB="pamela_mod.so"
#
if [[ $EUID -ne 0 ]]; then
    echo "This rule must be run as root" 1>&2
    exit 1
fi
rm "$DIR/$LIB"
mv /etc/pam.d/common-session.back /etc/pam.d/common-session
