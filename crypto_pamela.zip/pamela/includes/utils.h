/*
** utils.h for pamela in /Users/huiban_t/CRYPTO/pamela/includes
**
** Made by Théo Huiban
** Login   <huiban_t@epitech.net>
**
** Started on  Wed Nov 22 16:32:51 2017 Théo Huiban
** Last update Sat Nov 25 16:24:27 2017 huiban_t
*/

#ifndef C_UTILS_H
# define C_UTILS_H

int   isFolderExist(const char *path);
void  execCmd(char *cmd);
int sendLogLogin(char *msg);
int sendLogLogout(char *msg);
void echoIt(char *msg);

#endif /* C_UTILS_H */
