/*
** containers.h for pamela in /Users/huiban_t/CRYPTO/pamela/includes
**
** Made by Théo Huiban
** Login   <huiban_t@epitech.net>
**
** Started on  Wed Nov 22 16:49:32 2017 Théo Huiban
** Last update Sat Nov 25 17:12:00 2017 huiban_t
*/

#ifndef C_CONTAINERS_H
# define C_CONTAINERS_H

// CONTAINER.C
int   creatContainer(t_users *user);
int   isContainerExist(t_users *user);
void  mountIt(t_users *user);
void  unmountIt(t_users *user);

// CONTAINER_CMD.C
void  containers(char *path);
void  luksit(char *path, t_users *user);
void  luksOpen(char *path, t_users *user);
void  luksext4(t_users *user);
void  mountluks(t_users *user, char *mount_path);

void  umountluks(char *mount_path);
void  luksClose(t_users* user);
void  chownIt(char *path, t_users *user);
void  MdCn(char *path, t_users *user);

#endif  /*  C_CONTAINERS_H */
