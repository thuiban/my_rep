/*
** decrypt.h for pamela in /Users/huiban_t/CRYPTO/pamela/includes
**
** Made by Théo Huiban
** Login   <huiban_t@epitech.net>
**
** Started on  Thu Nov 23 16:48:13 2017 Théo Huiban
** Last update Thu Nov 23 16:49:42 2017 Théo Huiban
*/

#ifndef C_DECRYPT_H
# define C_DECRYPT_H

int   decrypt_start(t_users *user);

#endif /* C_DECRYPT_H */
