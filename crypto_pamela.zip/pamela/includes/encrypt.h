/*
** encrypt.h for pamela in /Users/huiban_t/CRYPTO/pamela/includes
**
** Made by Théo Huiban
** Login   <huiban_t@epitech.net>
**
** Started on  Thu Nov 23 16:50:59 2017 Théo Huiban
** Last update Thu Nov 23 16:52:26 2017 Théo Huiban
*/

#ifndef C_ENCRYPT_H
# define C_ENCRYPT_H

void encrypt_start(t_users *user);

#endif  /* C_ENCRYPT_H */
