/*
** users.h for pamela in /Users/huiban_t/CRYPTO/pamela/includes
**
** Made by Théo Huiban
** Login   <huiban_t@epitech.net>
**
** Started on  Wed Nov 22 16:42:13 2017 Théo Huiban
** Last update Thu Nov 23 15:04:21 2017 Théo Huiban
*/

#ifndef C_USERS_H
# define C_USERS_H

typedef struct s_users
{
    const char *name;
    char       *home;
    char       *user_keyfile;
}             t_users;

t_users        *setUsers(pam_handle_t *pamh);
const char     *getUser(t_users *user);
void           createKeyfile(t_users **user, char *path);
void           getKeyfile(t_users **users, char *path);

#endif /*  C_USERS_H  */
