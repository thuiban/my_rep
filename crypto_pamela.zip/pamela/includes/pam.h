/*
** pam.h for pamela in /Users/huiban_t/CRYPTO/pamela/includes
**
** Made by Théo Huiban
** Login   <huiban_t@epitech.net>
**
** Started on  Wed Nov 22 16:11:06 2017 Théo Huiban
** Last update Sat Nov 25 16:19:00 2017 huiban_t
*/


#ifndef C_PAMEPITECH_H
# define C_PAMEPITECH_H

// PERSONAL DEFINES
#define TRUE 1
#define FALSE 0

#define EXT   "_cont"
#define SIZE  128

// PAM MODULE DEFINES
#define PAM_SM_ACCOUNT
#define PAM_SM_AUTH
#define PAM_SM_PASSWORD
#define PAM_SM_SESSION

// SYSTEM INCLUDES
#include <security/pam_appl.h>
#include <security/pam_modules.h>

// SYSTEM INCLUDES
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <time.h>

// PERSONAL INCLUDES
#include "users.h"
#include "utils.h"
#include "containers.h"
#include "encrypt.h"
#include "decrypt.h"

#endif /* C_PAM_H */
