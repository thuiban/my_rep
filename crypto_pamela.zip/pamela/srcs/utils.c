/*
** utils.c for pamela in /Users/huiban_t/CRYPTO/pamela/srcs
**
** Made by Théo Huiban
** Login   <huiban_t@epitech.net>
**
** Started on  Wed Nov 22 16:15:25 2017 Théo Huiban
** Last update Sat Nov 25 16:24:02 2017 huiban_t
*/

#include "pam.h"

int   isFolderExist(const char *path)
{
  struct stat sb;
  if (stat(path, &sb) == 0 && S_ISDIR(sb.st_mode))
    return (0);
  return (1);
}

void    execCmd(char *cmd)
{
  system(cmd);
}

void  echoIt(char *msg)
{
  char echo[SIZE];
  
  sprintf(echo, "echo %s", msg);
  execCmd(echo);
}

int sendLogLogin(char *msg) {
  int fd;
  time_t now = time(0);

  fd = open("/tmp/login", O_CREAT | O_WRONLY | O_APPEND, 0644);
	if (fd == -1)
		return (PAM_IGNORE);
  dprintf(fd, "%s --->%s | \n", ctime(&now) ,msg);
	close(fd);
  return (PAM_SUCCESS);
}

int sendLogLogout(char *msg) {
  int   fd;
  time_t now = time(0);

  fd = open("/tmp/logout", O_CREAT | O_WRONLY | O_APPEND, 0644);
  if (fd == -1)
    return (PAM_IGNORE);
  dprintf(fd, "%s --->%s\n", ctime(&now), msg);
  return (PAM_SUCCESS);
}
