/*
** container_cmd.c for Pamela in /Users/huiban_t/CRYPTO/pamela/srcs
**
** Made by huiban_t
** Login   <huiban_t@epitech.eu>
**
** Started on  Sat Nov 25 15:33:58 2017 huiban_t
** Last update Sat Nov 25 17:06:52 2017 huiban_t
*/

#include "pam.h"

void  containers(char *path)
{
 char cmd[SIZE];

 sprintf(cmd, "fallocate -l 10G %s", path);
 execCmd(cmd);
}

void  luksit(char *path, t_users *user)
{
  char cmd[SIZE];

  sprintf(cmd, "echo \"YES\" | cryptsetup  luksFormat %s %s", path, user->user_keyfile);
  execCmd(cmd);
}

void luksOpen(char *path, t_users *user)
{
  char  cmd[SIZE];

  sprintf(cmd, "cryptsetup --key-file %s luksOpen %s volume_%s", user->user_keyfile ,path, user->name);
  execCmd(cmd);
}

void  luksext4(t_users *user)
{
  char cmd[SIZE];

  sprintf(cmd, "mkfs.ext4 -j /dev/mapper/volume_%s > /dev/null", user->name);
  execCmd(cmd);
}

void mountluks(t_users *user, char *mount_path)
{
  char cmd[SIZE];

  sprintf(cmd, "mount /dev/mapper/volume_%s %s", user->name, mount_path);
  execCmd(cmd);
}

void umountluks(char *mount_path)
{
  char  cmd[SIZE];

  sprintf(cmd, "umount %s", mount_path);
  execCmd(cmd);
}

void luksClose(t_users* user)
{
  char cmd[SIZE];

  sprintf(cmd, "cryptsetup luksClose volume_%s", user->name);
  execCmd(cmd);
}

void chownIt(char *path, t_users *user)
{
    char cmd[SIZE];
    
    sprintf(cmd, "chown -R %s %s", user->name, path);
    execCmd(cmd);
}

void  MdCn(char *path, t_users *user)
{
    char cmd[SIZE];

    sprintf(cmd, "mkdir %s && chown -R %s %s", path, user->name, path);
    execCmd(cmd);
}