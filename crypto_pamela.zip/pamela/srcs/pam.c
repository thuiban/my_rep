/*
** lib.c for Pam in /home/huiban_t/pamela
**
** Made by Theo  HUIBAN
** Login   <theo.huiban@epitech.eu>
**
** Started on  Mon Nov 20 14:07:41 2017 Theo  HUIBAN
** Last update Fri Nov 24 11:31:48 2017 Théo Huiban
*/

#include "pam.h"

int pam_sm_open_session(pam_handle_t *pamh, int flags, int argc, const char **argv)
{
	char *msg;
	t_users* ret = setUsers(pamh);

	if (ret == NULL)
		return (PAM_IGNORE);
	msg = strdup(strcat(strdup("Login of "), ret->name));
	sendLogLogin(msg);
	free(msg);
	msg = strdup(strcat(strdup("This home is "), strdup(ret->home)));
	sendLogLogin(msg);
	free(msg);
	decrypt_start(ret);
	return (PAM_SUCCESS);
}

int pam_sm_close_session(pam_handle_t *pamh, int flags, int argc, const char **argv)
{
	t_users* ret = setUsers(pamh);

	sendLogLogout(strcat(strdup("Logout of "), ret->name));
	encrypt_start(ret);
	return (PAM_SUCCESS);
}
