/*
** encrypt.c for pamela in /Users/huiban_t/CRYPTO/pamela/srcs
**
** Made by Théo Huiban
** Login   <huiban_t@epitech.net>
**
** Started on  Thu Nov 23 16:44:08 2017 Théo Huiban
** Last update Thu Nov 23 16:52:42 2017 Théo Huiban
*/

#include "pam.h"

void encrypt_start(t_users *user)
{
  unmountIt(user);
}
