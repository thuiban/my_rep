/*
** decrypt.c for pamela in /Users/huiban_t/CRYPTO/pamela/srcs
**
** Made by Théo Huiban
** Login   <huiban_t@epitech.net>
**
** Started on  Thu Nov 23 15:23:00 2017 Théo Huiban
** Last update Sat Nov 25 16:27:30 2017 huiban_t
*/

#include "pam.h"

int   decrypt_start(t_users *user)
{
  sendLogLogin("Decrypt of container starting");
  if (isContainerExist(user) != 0){
    creatContainer(user);
  }
  else {
    mountIt(user);
  }
}
