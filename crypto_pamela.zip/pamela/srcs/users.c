/*
** users.c for pamela in /Users/huiban_t/CRYPTO/pamela/srcs
**
** Made by Théo Huiban
** Login   <huiban_t@epitech.net>
**
** Started on  Wed Nov 22 16:52:59 2017 Théo Huiban
** Last update Thu Nov 23 15:09:38 2017 Théo Huiban
*/

#include "pam.h"

t_users  *setUsers(pam_handle_t *pamh)
{
  t_users *ret;
  int pgu_ret;

  if ((ret = malloc(sizeof(*ret))) == NULL)
    return (NULL);
  ret->name = NULL;
	ret->home = NULL;
  ret->user_keyfile = NULL;
  pgu_ret = pam_get_user(pamh, &ret->name, NULL);
  if (pgu_ret != PAM_SUCCESS || ret->name == NULL)
    return (NULL);
  if (strcmp("root", ret->name) == 0)
    ret->home = strdup("/root");
	else
	{
    ret->home = strcat(strdup("/home/"), strdup(ret->name));
    sendLogLogin(ret->home);
	}
  return (ret);
}

const char    *getUser(t_users *user)
{
  return (user->name);
}

void        createKeyfile(t_users **user, char *path)
{
  char  cmd[SIZE];

  sprintf(cmd, "head /dev/urandom | tr -dc A-Za-z0-9 | head -c 8 > %s/keyfile");
  execCmd(cmd);
  (*user)->user_keyfile = strdup(path);
  (*user)->user_keyfile = strcat((*user)->user_keyfile, strdup("/keyfile"));
}

void    getKeyfile(t_users **user, char *path)
{
  (*user)->user_keyfile = strdup(path);
  (*user)->user_keyfile = strcat((*user)->user_keyfile, strdup("/keyfile"));
}