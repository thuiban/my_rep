/*
** containers.c for pamela in /Users/huiban_t/CRYPTO/pamela/srcs
**
** Made by Théo Huiban
** Login   <huiban_t@epitech.net>
**
** Started on  Wed Nov 22 16:40:36 2017 Théo Huiban
** Last update Sat Nov 25 17:23:02 2017 huiban_t
*/

#include "pam.h"

int   creatContainer(t_users *user)
{
  char folder[SIZE];
  char allpath[SIZE];
  char mount_path[SIZE];

  sprintf(folder, "%s/.container", user->home);
  sprintf(allpath, "%s/%s%s", folder, user->name, EXT);
  sprintf(mount_path, "%s/secure_data-rw/", user->home);
  if (isFolderExist(folder) != 0)
  {
    sendLogLogin("folder will be created");
    MdCn(folder, user);
  }
    createKeyfile(&user, folder);
    containers(allpath);
    luksit(allpath, user);
    luksOpen(allpath, user);
    luksext4(user);
  if (isFolderExist(mount_path) != 0)
    {
      MdCn(mount_path, user);
    }
    mountluks(user, mount_path);
    chownIt(mount_path, user);
}

int      isContainerExist(t_users *user)
{
  char *path = strdup(user->home);
  path = strcat(path, strdup("/.container/"));
  path = strcat(path, strdup(user->name));
  path = strcat(path, EXT);
  if (access(path, F_OK) == 0)
    return (0);
  return (1);
}

void mountIt(t_users *user)
{
  char folder[SIZE];
  char allpath[SIZE];
  char mount_path[SIZE];

  sprintf(folder, "%s/.container", user->home);
  sprintf(allpath, "%s/%s%s", folder, user->name, EXT);
  sprintf(mount_path, "%s/secure_data-rw/", user->home);

  getKeyfile(&user, folder);
  luksOpen(allpath, user);
  mountluks(user, mount_path);
  chownIt(mount_path, user);
}

void unmountIt(t_users *user) {
    char mount_path[SIZE];
    
    sprintf(mount_path, "%s/secure_data-rw", user->home);
    umountluks(mount_path);
    luksClose(user);
}


