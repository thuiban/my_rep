## Pamela

Modules d'authentification enfichables capable de créer, de chiffrer et monter un container de 10GO pour chaque utilisateur.
Fonctionne uniquement avec des syst

## INSTALATION
L'installation doit ce faire en tant que root.
Si vous êtes root:
$ make install
Sinon:
$ sudo make install

## DESINSTALATION
La desinstalation dois ce faire en tant que root
Si vous êtes root:
$ make install
Sinon:
$ sudo make install

## PRINCIPE

Lors de la premiere connection avec le module PAM, il va créer a l'utilisateur un containeur chiffré. Et va ensuite le monter dans le dossier principal dans un dossier dans "~/secure_data-rw".


